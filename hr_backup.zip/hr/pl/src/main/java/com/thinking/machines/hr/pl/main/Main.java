package com.thinking.machines.hr.pl;
import com.thinking.machines.hr.pl.ui.*;
class Main
{
public static void main(String args[])
{
DesignationUI designationUI=new DesignationUI();
designationUI.setVisible(true);
}
}