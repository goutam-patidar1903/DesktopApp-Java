package com.thinking.machines.enums;
public enum GENDER{MALE,FEMALE}